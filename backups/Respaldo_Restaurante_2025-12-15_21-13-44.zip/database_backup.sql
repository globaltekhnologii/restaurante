-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: menu_restaurante
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `direccion_principal` text DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `ultimo_pedido` datetime DEFAULT NULL,
  `total_pedidos` int(11) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telefono` (`telefono`),
  KEY `idx_telefono` (`telefono`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'claudia','alzate','3025887988','claudialzate1234@hotmail.com',NULL,'carrera 2#26E-28','tulua','','2025-12-05 04:41:00','2025-12-13 02:17:21',15,1),(2,'claudia alzate','','3177731338','',NULL,'carrera 2#26E-28','',NULL,'2025-12-08 03:26:04',NULL,0,1),(3,'claudia alzate','','3025887986','',NULL,'carrera 2#26E-28','',NULL,'2025-12-08 03:32:24','2025-12-08 05:07:36',4,1),(4,'Juan Pérez','','3109876543','',NULL,'Calle 25 #15-30 Barrio Centro','',NULL,'2025-12-08 23:11:17','2025-12-08 23:11:17',1,1),(5,'Usuario prueba',NULL,'3001234567','test@restaurante.com','$2y$10$qPElElo84afp8gHLO9l56u9sr84MB7UekwcHE9dznsQJ0PLSYiPga','calle 123',NULL,NULL,'2025-12-11 20:52:02',NULL,0,1);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_domicilios`
--

DROP TABLE IF EXISTS `configuracion_domicilios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_domicilios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarifa_base` decimal(10,2) NOT NULL DEFAULT 5000.00 COMMENT 'Tarifa fija mínima en COP',
  `costo_por_km` decimal(10,2) NOT NULL DEFAULT 1000.00 COMMENT 'Costo adicional por kilómetro',
  `distancia_maxima` decimal(10,2) DEFAULT 10.00 COMMENT 'Distancia máxima en km',
  `usar_rangos` tinyint(1) DEFAULT 0 COMMENT '1=usar rangos, 0=usar tarifa base+km',
  `activo` tinyint(1) DEFAULT 1,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_domicilios`
--

LOCK TABLES `configuracion_domicilios` WRITE;
/*!40000 ALTER TABLE `configuracion_domicilios` DISABLE KEYS */;
INSERT INTO `configuracion_domicilios` VALUES (1,4000.00,500.00,5.00,0,1,'2025-12-09 03:12:01');
/*!40000 ALTER TABLE `configuracion_domicilios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_sistema`
--

DROP TABLE IF EXISTS `configuracion_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_restaurante` varchar(100) NOT NULL DEFAULT 'Restaurante El Sabor',
  `logo_url` varchar(255) DEFAULT 'img/logo_default.png',
  `direccion` varchar(255) DEFAULT 'Calle Principal #123',
  `telefono` varchar(50) DEFAULT '555-0123',
  `email` varchar(100) DEFAULT 'contacto@restaurante.com',
  `sitio_web` varchar(100) DEFAULT 'www.restaurante.com',
  `facebook` varchar(100) DEFAULT '',
  `instagram` varchar(100) DEFAULT '',
  `horario_atencion` text DEFAULT 'Lunes a Domingo: 12:00 PM - 10:00 PM',
  `pais` varchar(50) DEFAULT 'Colombia',
  `departamento` varchar(50) DEFAULT 'Cundinamarca',
  `ciudad` varchar(50) DEFAULT 'Bogotá',
  `moneda` varchar(10) DEFAULT 'COP',
  `impuesto_porcentaje` decimal(5,2) DEFAULT 0.00,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `horario_apertura_domicilios` time DEFAULT '09:00:00',
  `horario_cierre_domicilios` time DEFAULT '22:00:00',
  `domicilios_habilitados` tinyint(1) DEFAULT 1,
  `latitud_restaurante` decimal(10,8) DEFAULT NULL COMMENT 'Latitud del restaurante',
  `longitud_restaurante` decimal(10,8) DEFAULT NULL COMMENT 'Longitud del restaurante',
  `nit` varchar(20) DEFAULT '',
  `mensaje_pie_factura` text DEFAULT '¡Gracias por su compra!',
  `dias_laborales` text DEFAULT '["1","2","3","4","5","6","7"]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_sistema`
--

LOCK TABLES `configuracion_sistema` WRITE;
/*!40000 ALTER TABLE `configuracion_sistema` DISABLE KEYS */;
INSERT INTO `configuracion_sistema` VALUES (1,'Dburger','img/logo_negocio.jpg','carrera 2 # 26E-28','3177731338','tuluadburger@gmail.com','https://global-tekhnologii.blogspot.com/','','','Lunes a Domingo: 12:00 PM - 10:00 PM','colombia','valle del cauca','Tulua','COP',0.00,'2025-12-09 05:03:40','00:03:00','23:59:59',1,4.09014392,-76.21252030,'','¡Gracias por su compra!','[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\"]');
/*!40000 ALTER TABLE `configuracion_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `direcciones_clientes`
--

DROP TABLE IF EXISTS `direcciones_clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `direcciones_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `direccion` text NOT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `referencia` text DEFAULT NULL,
  `es_principal` tinyint(1) DEFAULT 0,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cliente` (`cliente_id`),
  CONSTRAINT `direcciones_clientes_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direcciones_clientes`
--

LOCK TABLES `direcciones_clientes` WRITE;
/*!40000 ALTER TABLE `direcciones_clientes` DISABLE KEYS */;
INSERT INTO `direcciones_clientes` VALUES (1,2,'Principal','carrera 2#26E-28','',NULL,1,'2025-12-08 03:26:04'),(2,3,'Principal','carrera 2#26E-28','',NULL,1,'2025-12-08 03:32:24'),(3,4,'Principal','Calle 25 #15-30 Barrio Centro','',NULL,1,'2025-12-08 23:11:17');
/*!40000 ALTER TABLE `direcciones_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredientes`
--

DROP TABLE IF EXISTS `ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `unidad_medida` enum('kg','litros','unidades','gramos','ml') DEFAULT 'unidades',
  `stock_actual` decimal(10,2) DEFAULT 0.00,
  `stock_minimo` decimal(10,2) DEFAULT 0.00,
  `stock_maximo` decimal(10,2) DEFAULT 0.00,
  `precio_unitario` decimal(10,2) DEFAULT 0.00,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `fecha_actualizacion` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_activo` (`activo`),
  KEY `idx_stock_actual` (`stock_actual`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredientes`
--

LOCK TABLES `ingredientes` WRITE;
/*!40000 ALTER TABLE `ingredientes` DISABLE KEYS */;
INSERT INTO `ingredientes` VALUES (1,'Tomate','Tomate fresco','Verduras','kg',10.00,5.00,20.00,2500.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(2,'Cebolla','Cebolla blanca','Verduras','kg',8.00,3.00,15.00,2000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(3,'Ajo','Ajo en cabeza','Verduras','kg',2.00,1.00,5.00,8000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(4,'Pollo','Pechuga de pollo','Carnes','kg',15.00,10.00,30.00,12000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(5,'Carne de res','Carne molida','Carnes','kg',12.00,8.00,25.00,18000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(6,'Arroz','Arroz blanco','Granos','kg',25.00,10.00,50.00,3000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(7,'Pasta','Pasta spaghetti','Granos','kg',20.00,8.00,40.00,4000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(8,'Aceite','Aceite vegetal','Condimentos','litros',5.00,2.00,10.00,8000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(9,'Sal','Sal de cocina','Condimentos','kg',3.00,1.00,5.00,1500.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32'),(10,'Queso','Queso mozzarella','Lácteos','kg',6.00,3.00,12.00,15000.00,1,'2025-12-07 11:06:32','2025-12-07 11:06:32');
/*!40000 ALTER TABLE `ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesas`
--

DROP TABLE IF EXISTS `mesas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mesas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_mesa` varchar(10) NOT NULL,
  `capacidad` int(11) DEFAULT 4,
  `estado` enum('disponible','ocupada','reservada') DEFAULT 'disponible',
  `pedido_actual` int(11) DEFAULT NULL,
  `mesero_asignado` int(11) DEFAULT NULL,
  `fecha_ocupacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_mesa` (`numero_mesa`),
  KEY `pedido_actual` (`pedido_actual`),
  KEY `idx_numero_mesa` (`numero_mesa`),
  KEY `idx_estado` (`estado`),
  KEY `idx_mesero_asignado` (`mesero_asignado`),
  CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`pedido_actual`) REFERENCES `pedidos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mesas_ibfk_2` FOREIGN KEY (`mesero_asignado`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesas`
--

LOCK TABLES `mesas` WRITE;
/*!40000 ALTER TABLE `mesas` DISABLE KEYS */;
INSERT INTO `mesas` VALUES (1,'Mesa 1',2,'disponible',59,5,'2025-12-13 01:55:12'),(2,'Mesa 2',4,'disponible',NULL,NULL,NULL),(3,'Mesa 3',4,'disponible',NULL,NULL,NULL),(4,'Mesa 4',6,'disponible',NULL,NULL,NULL),(5,'Mesa 5',2,'disponible',NULL,NULL,NULL),(6,'Mesa 6',4,'disponible',NULL,NULL,NULL),(7,'Mesa 7',8,'disponible',23,5,'2025-12-05 08:00:14'),(8,'Mesa 8',4,'disponible',NULL,NULL,NULL),(9,'Mesa 9',2,'disponible',21,5,'2025-12-05 06:06:17'),(10,'Mesa 10',6,'disponible',56,5,'2025-12-13 01:40:01');
/*!40000 ALTER TABLE `mesas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodos_pago_config`
--

DROP TABLE IF EXISTS `metodos_pago_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metodos_pago_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metodo` varchar(50) NOT NULL,
  `nombre_display` varchar(100) NOT NULL,
  `numero_cuenta` varchar(100) DEFAULT NULL,
  `nombre_titular` varchar(100) DEFAULT NULL,
  `qr_imagen` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `orden` int(11) DEFAULT 0,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `metodo` (`metodo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodos_pago_config`
--

LOCK TABLES `metodos_pago_config` WRITE;
/*!40000 ALTER TABLE `metodos_pago_config` DISABLE KEYS */;
INSERT INTO `metodos_pago_config` VALUES (1,'efectivo','Efectivo',NULL,NULL,NULL,1,1,'2025-12-05 01:05:42'),(2,'nequi','Nequi','3177731338','Edwar Jaramillo ','imagenes_qr/nequi_qr_1764897699.jpg',1,2,'2025-12-05 01:21:39'),(3,'daviplata','Daviplata','3177731338','Edwar Jaramillo ','imagenes_qr/daviplata_qr_1764897733.png',1,3,'2025-12-05 01:22:13'),(4,'dale','Dale',NULL,NULL,NULL,1,4,'2025-12-05 01:05:42'),(5,'bancolombia','Bancolombia Ahorros','76200044335','Claudia alzate ','imagenes_qr/bancolombia_qr_1764898477.png',1,5,'2025-12-05 01:34:37');
/*!40000 ALTER TABLE `metodos_pago_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_inventario`
--

DROP TABLE IF EXISTS `movimientos_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ingrediente_id` int(11) NOT NULL,
  `tipo_movimiento` enum('entrada','salida','ajuste','merma') NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `stock_anterior` decimal(10,2) NOT NULL,
  `stock_nuevo` decimal(10,2) NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `fecha_movimiento` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `proveedor_id` (`proveedor_id`),
  KEY `idx_ingrediente` (`ingrediente_id`),
  KEY `idx_tipo` (`tipo_movimiento`),
  KEY `idx_fecha` (`fecha_movimiento`),
  CONSTRAINT `movimientos_inventario_ibfk_1` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `movimientos_inventario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `movimientos_inventario_ibfk_3` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_inventario`
--

LOCK TABLES `movimientos_inventario` WRITE;
/*!40000 ALTER TABLE `movimientos_inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `numero_transaccion` varchar(50) DEFAULT NULL,
  `metodo_pago` enum('efectivo','nequi','daviplata','dale','bancolombia','otro') DEFAULT 'efectivo',
  `referencia_pago` varchar(100) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha_pago` datetime DEFAULT current_timestamp(),
  `usuario_id` int(11) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_transaccion` (`numero_transaccion`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_pedido` (`pedido_id`),
  KEY `idx_fecha` (`fecha_pago`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,10,'TXN-20251205-0010-3351','efectivo','',5000.00,'2025-12-04 21:48:41',1,''),(2,9,'TXN-20251205-0009-1718','efectivo','',2005.00,'2025-12-04 21:50:24',1,''),(3,12,'TXN-20251205-0012-8620','efectivo','',2005.00,'2025-12-04 23:37:15',1,''),(9,1,'TXN-20251205-0001-3411','efectivo','',31005.00,'2025-12-05 01:15:47',1,''),(10,2,'TXN-20251205-0002-8783','efectivo','',12005.00,'2025-12-05 01:16:32',1,''),(14,16,'TXN-20251205-0016-6825','efectivo','',2005.00,'2025-12-05 04:56:27',1,''),(28,7,'TXN-20251205-0007-9504','efectivo','',2000.00,'2025-12-05 06:03:13',5,''),(29,11,'TXN-20251205-0011-7664','efectivo','',5000.00,'2025-12-05 06:03:44',5,''),(30,14,'TXN-20251205-0014-4307','efectivo','',20000.00,'2025-12-05 06:04:10',5,''),(31,15,'TXN-20251205-0015-9987','efectivo','',5000.00,'2025-12-05 06:04:31',5,''),(32,17,'TXN-20251205-0017-7439','efectivo','',10000.00,'2025-12-05 06:04:54',5,''),(33,18,'TXN-20251205-0018-6978','efectivo','',5000.00,'2025-12-05 06:05:24',5,''),(34,19,'TXN-20251205-0019-3917','efectivo','',10000.00,'2025-12-05 06:05:39',5,''),(35,21,'TXN-20251205-0021-1376','efectivo','',31000.00,'2025-12-05 06:07:04',5,''),(36,20,'TXN-20251205-0020-4999','efectivo','',5000.00,'2025-12-05 06:42:55',1,''),(37,22,'TXN-20251205-0022-3614','efectivo','',45000.00,'2025-12-05 06:57:08',5,''),(38,5,'TXN-20251205-0005-3585','efectivo','',28005.00,'2025-12-05 07:48:00',7,''),(39,3,'TXN-20251205-0003-4680','efectivo','',27000.00,'2025-12-05 07:48:17',7,''),(40,4,'TXN-20251205-0004-3853','efectivo','',65000.00,'2025-12-05 07:48:32',7,''),(41,6,'TXN-20251205-0006-2763','efectivo','',2005.00,'2025-12-05 07:48:43',7,''),(42,8,'TXN-20251205-0008-6119','efectivo','',5005.00,'2025-12-05 07:48:52',7,''),(43,13,'TXN-20251205-0013-3227','efectivo','',7005.00,'2025-12-05 07:49:10',7,''),(44,23,'TXN-20251205-0023-4344','efectivo','',20000.00,'2025-12-05 08:04:14',7,''),(45,24,'TXN-20251205-0024-3400','efectivo','',10005.00,'2025-12-05 08:20:06',1,''),(46,25,'TXN-20251206-0025-9032','efectivo','',25000.00,'2025-12-06 02:23:34',7,''),(47,28,'TXN-20251208-0028-5790','efectivo','',30005.00,'2025-12-08 00:37:41',11,''),(48,26,'TXN-20251208-0026-8391','efectivo','',8000.00,'2025-12-08 00:38:12',11,''),(49,27,'TXN-20251208-0027-4279','efectivo','',8000.00,'2025-12-08 00:38:23',11,''),(50,29,'TXN-20251208-0029-9898','efectivo','',20000.00,'2025-12-08 00:38:33',11,''),(51,30,'TXN-20251208-0030-4234','efectivo','',20000.00,'2025-12-08 00:38:44',11,''),(52,31,'TXN-20251208-0031-8246','efectivo','',45000.00,'2025-12-08 00:38:57',11,''),(53,37,'TXN-20251208-0037-6889','efectivo','',25000.00,'2025-12-08 03:14:34',7,''),(54,36,'TXN-20251208-0036-9520','efectivo','',25000.00,'2025-12-08 03:18:57',7,''),(55,35,'TXN-20251208-0035-8732','efectivo','',25000.00,'2025-12-08 03:19:09',7,''),(56,34,'TXN-20251208-0034-6101','efectivo','',8000.00,'2025-12-08 03:19:19',7,''),(57,33,'TXN-20251208-0033-4827','efectivo','',15000.00,'2025-12-08 03:19:26',7,''),(58,32,'TXN-20251208-0032-3422','efectivo','',15000.00,'2025-12-08 03:19:33',7,''),(59,45,'TXN-20251208-0045-7386','efectivo','',25000.00,'2025-12-08 04:30:50',1,''),(60,44,'TXN-20251208-0044-6748','efectivo','',12005.00,'2025-12-08 04:31:08',1,''),(61,43,'TXN-20251208-0043-8438','efectivo','',15000.00,'2025-12-08 04:31:22',1,''),(62,42,'TXN-20251208-0042-3624','efectivo','',12005.00,'2025-12-08 04:31:37',1,''),(63,49,'TXN-20251208-0049-1774','efectivo','',19005.00,'2025-12-08 05:27:04',1,''),(64,48,'TXN-20251208-0048-7990','efectivo','',12005.00,'2025-12-08 05:27:32',1,''),(65,47,'TXN-20251208-0047-5075','efectivo','',12005.00,'2025-12-08 05:29:59',1,''),(66,46,'TXN-20251208-0046-4797','efectivo','',12005.00,'2025-12-08 05:33:58',1,''),(67,40,'TXN-20251208-0040-7290','efectivo','',12005.00,'2025-12-08 22:22:17',7,''),(68,41,'TXN-20251208-0041-5438','efectivo','',12005.00,'2025-12-08 22:22:25',7,''),(69,50,'TXN-20251208-0050-7589','efectivo','',29775.00,'2025-12-08 22:22:35',7,''),(70,55,'TXN-20251213-0055-2549','efectivo','',5000.00,'2025-12-13 00:08:47',7,''),(71,51,'TXN-20251213-0051-3703','efectivo','',52000.00,'2025-12-13 00:09:19',7,''),(72,52,'TXN-20251213-0052-1681','efectivo','',6415.00,'2025-12-13 00:09:28',7,''),(73,53,'TXN-20251213-0053-5255','efectivo','',7020.00,'2025-12-13 00:09:41',7,''),(74,54,'TXN-20251213-0054-1666','efectivo','',6790.00,'2025-12-13 00:09:54',7,''),(75,56,'TXN-20251213-0056-5656','efectivo','',28000.00,'2025-12-13 01:57:59',7,''),(76,57,'TXN-20251213-0057-4231','efectivo','',34500.00,'2025-12-13 01:58:37',7,''),(77,58,'TXN-20251213-0058-7625','efectivo','',1000.00,'2025-12-13 01:59:11',7,''),(78,59,'TXN-20251213-0059-9308','efectivo','',2000.00,'2025-12-13 01:59:25',7,''),(79,62,'TXN-20251213-0062-8440','efectivo','',6310.00,'2025-12-13 02:18:59',7,''),(80,61,'TXN-20251213-0061-2814','efectivo','',2000.00,'2025-12-13 02:19:09',7,''),(81,60,'TXN-20251213-0060-6805','efectivo','',6500.00,'2025-12-13 02:19:17',7,'');
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `numero_pedido` varchar(50) NOT NULL,
  `nombre_cliente` varchar(100) NOT NULL,
  `telefono_cliente` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` text NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` enum('pendiente','confirmado','preparando','listo','en_camino','entregado','cancelado') DEFAULT 'pendiente',
  `pagado` tinyint(1) DEFAULT 0,
  `notas` text DEFAULT NULL,
  `mesa_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL COMMENT 'Mesero que tomó el pedido',
  `domiciliario_id` int(11) DEFAULT NULL COMMENT 'Domiciliario asignado',
  `hora_salida` datetime DEFAULT NULL COMMENT 'Hora en que el domiciliario salió',
  `hora_entrega` datetime DEFAULT NULL COMMENT 'Hora de entrega confirmada',
  `fecha_pedido` datetime DEFAULT current_timestamp(),
  `fecha_actualizacion` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `metodo_pago_seleccionado` varchar(50) DEFAULT NULL,
  `pago_anticipado` tinyint(1) DEFAULT 0,
  `pago_validado` tinyint(1) DEFAULT 0,
  `referencia_pago_anticipado` varchar(100) DEFAULT NULL,
  `validacion_automatica` tinyint(1) DEFAULT 0,
  `tipo_pedido` enum('mesa','domicilio','para_llevar') DEFAULT 'mesa',
  `origen` varchar(20) DEFAULT 'web',
  `conversation_id` int(11) DEFAULT NULL,
  `notificado` tinyint(1) DEFAULT 0,
  `latitud_cliente` decimal(10,8) DEFAULT NULL COMMENT 'Latitud del cliente',
  `longitud_cliente` decimal(10,8) DEFAULT NULL COMMENT 'Longitud del cliente',
  `distancia_km` decimal(10,2) DEFAULT NULL COMMENT 'Distancia calculada en km',
  `costo_domicilio` decimal(10,2) DEFAULT NULL COMMENT 'Costo de domicilio calculado',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_pedido` (`numero_pedido`),
  KEY `idx_numero_pedido` (`numero_pedido`),
  KEY `idx_telefono` (`telefono`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha_pedido` (`fecha_pedido`),
  KEY `idx_mesa_id` (`mesa_id`),
  KEY `idx_usuario_id` (`usuario_id`),
  KEY `idx_domiciliario_id` (`domiciliario_id`),
  KEY `idx_pago_anticipado` (`pago_anticipado`),
  KEY `idx_pago_validado` (`pago_validado`),
  KEY `idx_tipo_pedido` (`tipo_pedido`),
  KEY `idx_cliente` (`cliente_id`),
  CONSTRAINT `fk_pedidos_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,NULL,'PED-20251204-6E8F8C','edwar jaramillo',NULL,'3025887986','carrera 2#26E-28','edwarjm@gmail.com',31005.00,'entregado',1,'',NULL,NULL,NULL,NULL,NULL,'2025-12-04 00:03:02','2025-12-05 01:15:47',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(2,NULL,'PED-20251204-1DE4FD','claudia',NULL,'3025887988','carrera 2 # 26-28','',12005.00,'entregado',1,'',NULL,NULL,NULL,NULL,NULL,'2025-12-04 00:46:41','2025-12-05 01:16:32',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(3,NULL,'PED-20251204-3179','claudia alzate',NULL,'3025887986','',NULL,27000.00,'entregado',1,'',2,2,NULL,NULL,NULL,'2025-12-04 12:29:22','2025-12-05 07:48:17',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(4,NULL,'PED-20251204-1347','claudia alzate',NULL,'3025887986','',NULL,65000.00,'entregado',1,'',10,2,NULL,NULL,NULL,'2025-12-04 12:31:08','2025-12-05 07:48:32',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(5,NULL,'PED-20251204-CCEDCC','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',28005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 12:49:44','2025-12-04 12:50:32','2025-12-04 12:46:04','2025-12-05 07:48:00',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(6,NULL,'PED-20251205-D64FA7','emmanuel',NULL,'3025887986','carrera 2#26E-28','',2005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 20:01:40','2025-12-04 20:02:30','2025-12-04 19:53:49','2025-12-05 07:48:43',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(7,NULL,'PED-20251205-9888','caludia',NULL,'3025887986','',NULL,2000.00,'entregado',1,'',10,5,NULL,NULL,'2025-12-04 21:27:04','2025-12-04 20:45:10','2025-12-05 06:03:13',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(8,NULL,'PED-20251205-BDDF61','claudia',NULL,'3025887986','carrera 2#26E-28','',5005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 21:09:46','2025-12-04 21:10:57','2025-12-04 20:48:11','2025-12-05 07:48:52',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(9,NULL,'PED-20251205-AF0C31','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',2005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 21:34:31','2025-12-04 21:35:01','2025-12-04 21:29:30','2025-12-04 21:50:24',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(10,NULL,'PED-20251205-4377','edwar',NULL,'3028557988','',NULL,5000.00,'entregado',1,'',2,5,NULL,NULL,'2025-12-04 21:35:59','2025-12-04 21:33:07','2025-12-04 21:48:41',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(11,NULL,'PED-20251205-8742','claudia',NULL,'3025887986','',NULL,5000.00,'entregado',1,'',10,5,NULL,NULL,'2025-12-05 00:31:02','2025-12-04 22:47:51','2025-12-05 06:03:44',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(12,NULL,'PED-20251205-88A1A8','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',2005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 23:26:12','2025-12-04 23:36:36','2025-12-04 23:20:24','2025-12-04 23:37:15',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(13,NULL,'PED-20251205-10B27A','edwar',NULL,'3025887986','Para Llevar - Recogida en local','',7005.00,'entregado',1,'',NULL,NULL,4,'2025-12-04 23:42:25','2025-12-04 23:42:29','2025-12-04 23:39:13','2025-12-05 07:49:10',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(14,NULL,'PED-20251205-4583','claudia',NULL,'3028557986','',NULL,20000.00,'entregado',1,'',10,5,NULL,NULL,'2025-12-05 00:29:38','2025-12-04 23:52:06','2025-12-05 06:04:10',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(15,NULL,'PED-20251205-6682','claudia',NULL,'3025887986','',NULL,5000.00,'entregado',1,'',2,5,NULL,NULL,'2025-12-05 00:28:08','2025-12-05 00:04:46','2025-12-05 06:04:31',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(16,1,'PED-20251205-B7C740','claudia alzate',NULL,'3025887988','carrera 2#26E-28','',2005.00,'entregado',1,'',NULL,NULL,4,'2025-12-05 04:54:58','2025-12-05 04:55:41','2025-12-05 04:50:03','2025-12-05 04:56:27',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(17,NULL,'PED-20251205-6401','claudia alzate',NULL,'3025887988','',NULL,10000.00,'entregado',1,'',1,5,NULL,NULL,'2025-12-05 05:10:41','2025-12-05 05:01:35','2025-12-05 06:04:54',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(18,NULL,'PED-20251205-2155','claudia alzate',NULL,'3025887988','',NULL,5000.00,'entregado',1,'',10,5,NULL,NULL,'2025-12-05 05:28:16','2025-12-05 05:25:46','2025-12-05 06:05:24',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(19,NULL,'PED-20251205-9171','claudia alzate',NULL,'3025887988','',NULL,10000.00,'entregado',1,'',4,5,NULL,NULL,'2025-12-05 05:37:13','2025-12-05 05:35:30','2025-12-05 06:05:39',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(20,NULL,'PED-20251205-1707','claudia alzate',NULL,'3025887986','',NULL,5000.00,'entregado',1,'',10,5,NULL,NULL,'2025-12-05 06:42:47','2025-12-05 05:48:25','2025-12-05 06:42:55',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(21,NULL,'PED-20251205-6263','claudia',NULL,'3025887988','',NULL,31000.00,'entregado',1,'',9,5,NULL,NULL,'2025-12-05 06:07:26','2025-12-05 06:06:17','2025-12-05 06:07:26',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(22,NULL,'PED-20251205-1842','claudia alzate',NULL,'3025887988','',NULL,45000.00,'entregado',1,'',1,5,NULL,NULL,'2025-12-05 06:56:44','2025-12-05 06:37:39','2025-12-05 06:57:08',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(23,NULL,'PED-20251205-9459','claudia alzate',NULL,'3025887988','',NULL,20000.00,'entregado',1,'',7,5,NULL,NULL,'2025-12-05 08:17:27','2025-12-05 08:00:14','2025-12-05 08:17:27',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(24,1,'PED-20251205-897F66','claudia alzate',NULL,'3025887988','carrera 2#26E-28','',10005.00,'entregado',1,'',NULL,NULL,4,NULL,'2025-12-05 08:19:48','2025-12-05 08:11:20','2025-12-05 08:20:06',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(25,NULL,'TEST-0217','Test Chatbot User',NULL,'1234567890','Calle Test 123',NULL,25000.00,'entregado',1,NULL,NULL,NULL,NULL,NULL,'2025-12-08 00:58:04','2025-12-06 02:17:49','2025-12-08 00:58:04',NULL,0,0,NULL,0,'domicilio','chatbot',999,0,NULL,NULL,NULL,NULL),(26,NULL,'BOT-251206-151','Edwar Jaramillo',NULL,'3025887986','Carrera 2 26E 28',NULL,8000.00,'entregado',1,NULL,NULL,NULL,NULL,NULL,'2025-12-08 00:57:59','2025-12-06 02:36:00','2025-12-08 00:57:59',NULL,0,0,NULL,0,'domicilio','chatbot',16,0,NULL,NULL,NULL,NULL),(27,NULL,'BOT-251206-794','Edwar Jaramillo',NULL,'3025887986','Carrera 2 26E 28',NULL,8000.00,'entregado',1,NULL,NULL,NULL,NULL,NULL,'2025-12-08 00:57:51','2025-12-06 02:36:24','2025-12-08 00:57:51',NULL,0,0,NULL,0,'domicilio','chatbot',16,0,NULL,NULL,NULL,NULL),(28,1,'PED-20251208-FDB81B','claudia alzate',NULL,'3025887988','carrera 2#26E-28','',30005.00,'entregado',1,'',NULL,NULL,4,NULL,'2025-12-08 00:54:53','2025-12-08 00:04:47','2025-12-08 00:54:53',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(29,NULL,'BOT-251208-338','Claudia Alzate',NULL,'3025887988','Carrera 2 # 26E-28',NULL,20000.00,'entregado',1,NULL,NULL,NULL,NULL,NULL,'2025-12-08 00:57:38','2025-12-08 00:11:56','2025-12-08 00:57:38',NULL,0,0,NULL,0,'domicilio','chatbot',22,0,NULL,NULL,NULL,NULL),(30,NULL,'BOT-251208-384','Claudia Alzate',NULL,'3025887988','Kra 2 # 26E-28',NULL,20000.00,'entregado',1,NULL,NULL,NULL,NULL,NULL,'2025-12-08 00:54:13','2025-12-08 00:12:13','2025-12-08 00:54:13',NULL,0,0,NULL,0,'domicilio','chatbot',22,0,NULL,NULL,NULL,NULL),(31,NULL,'PED-20251208-7481','claudia alzate',NULL,'3025887988','',NULL,45000.00,'entregado',1,'',1,7,NULL,NULL,'2025-12-08 00:49:45','2025-12-08 00:15:58','2025-12-08 00:49:45',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(32,NULL,'BOT-251208-590','Claudia Alzate',NULL,'3025887988','carrera 2#26E-28',NULL,15000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:23:17','2025-12-08 01:11:53','2025-12-08 03:23:17',NULL,0,0,NULL,0,'domicilio','chatbot',23,0,NULL,NULL,NULL,NULL),(33,NULL,'BOT-251208-310','Claudia Alzate',NULL,'3025887988','carrera 2#26E-28',NULL,15000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:23:13','2025-12-08 01:12:16','2025-12-08 03:23:13',NULL,0,0,NULL,0,'domicilio','chatbot',23,0,NULL,NULL,NULL,NULL),(34,NULL,'BOT-251208-470','Claudia Alzate',NULL,'3025887988','Carrera 22 #26E-28',NULL,8000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:23:09','2025-12-08 01:23:27','2025-12-08 03:23:09',NULL,0,0,NULL,0,'domicilio','chatbot',24,0,NULL,NULL,NULL,NULL),(35,NULL,'TEST-251208-617','Cliente Prueba',NULL,'3001234567','0',NULL,25000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:23:03','2025-12-08 01:57:47','2025-12-08 03:23:03',NULL,0,0,NULL,0,'domicilio','manual',NULL,0,NULL,NULL,NULL,NULL),(36,NULL,'TEST-251208-663','Cliente Prueba',NULL,'3001234567','0',NULL,25000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:22:58','2025-12-08 02:02:09','2025-12-08 03:22:58',NULL,0,0,NULL,0,'domicilio','manual',NULL,0,NULL,NULL,NULL,NULL),(37,NULL,'TEST-251208-566','Cliente Prueba',NULL,'3001234567','0',NULL,25000.00,'entregado',1,NULL,NULL,NULL,4,NULL,'2025-12-08 03:08:01','2025-12-08 02:03:25','2025-12-08 03:14:34',NULL,0,0,NULL,0,'domicilio','manual',NULL,0,NULL,NULL,NULL,NULL),(40,3,'PED-20251208-85B727','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,NULL,NULL,'2025-12-08 04:30:42','2025-12-08 03:32:24','2025-12-08 22:22:17',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(41,3,'PED-20251208-369D3A','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,NULL,NULL,'2025-12-08 04:30:34','2025-12-08 03:44:35','2025-12-08 22:22:25',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(42,1,'PED-20251208-78371D','claudia alzate',NULL,'3025887988','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,NULL,NULL,'2025-12-08 04:30:31','2025-12-08 03:54:15','2025-12-08 04:31:37',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(43,NULL,'TEST-0357','Usuario Prueba',NULL,'555-1234','Calle Falsa 123',NULL,15000.00,'entregado',1,NULL,NULL,NULL,12,NULL,NULL,'2025-12-08 03:57:54','2025-12-08 04:31:22',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(44,3,'PED-20251208-674BF8','claudia alzate',NULL,'3025887986','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,NULL,NULL,'2025-12-08 04:30:27','2025-12-08 04:04:54','2025-12-08 04:31:08',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(45,NULL,'TEST-FULL-0426','Cliente Test Flow',NULL,'555-9999','Calle Prueba Flow 123',NULL,25000.00,'entregado',1,'Nota Test',0,2,6,NULL,NULL,'2025-12-08 04:26:39','2025-12-08 04:30:50',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(46,1,'PED-20251208-F66E6A','claudia',NULL,'3025887988','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,12,NULL,NULL,'2025-12-08 04:54:39','2025-12-08 05:33:58',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(47,1,'PED-20251208-946D98','claudia',NULL,'3025887988','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,12,NULL,NULL,'2025-12-08 04:55:05','2025-12-08 05:29:59',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(48,3,'PED-20251208-8C5C45','claudia',NULL,'3025887986','carrera 2#26E-28','',12005.00,'entregado',1,'',NULL,NULL,12,NULL,NULL,'2025-12-08 05:07:36','2025-12-08 05:27:32',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(49,1,'PED-20251208-BE3DD9','claudia',NULL,'3025887988','carrera 2#26E-28','',19005.00,'entregado',1,'',NULL,NULL,12,NULL,NULL,'2025-12-08 05:12:43','2025-12-08 05:27:04',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(50,1,'PED-20251208-954B22','Claudia',NULL,'3025887988','Calle 26 #11-50','',29775.00,'entregado',1,'',NULL,NULL,12,NULL,NULL,'2025-12-08 22:18:49','2025-12-08 22:22:35',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.08557260,-76.19927140,1.55,4775.00),(51,4,'PED-20251208-5CD0D1','Juan Pérez',NULL,'3109876543','Calle 25 #15-30 Barrio Centro','',52000.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-08 23:11:17','2025-12-13 00:09:19',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,5000.00),(52,1,'PED-20251208-44D9C2','claudia',NULL,'3025887988','calle 26 # 11-50','',6415.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-08 23:31:16','2025-12-13 00:09:28',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.08875870,-76.20513640,0.83,4415.00),(53,1,'PED-20251209-270D21','Claudia alzate',NULL,'3025887988','Calle 26 #10-50','',7020.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-09 00:04:34','2025-12-13 00:09:41',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.08472590,-76.19495400,2.04,5020.00),(54,1,'PED-20251211-2E0961','claudia',NULL,'3025887988','calle 25 # 11-50','',6790.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-11 21:14:42','2025-12-13 01:53:56',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.08640630,-76.19877020,1.58,4790.00),(55,NULL,'PED-20251213-7402','claudia alzate',NULL,'3025887988','',NULL,5000.00,'listo',1,'',1,5,NULL,NULL,NULL,'2025-12-13 00:07:40','2025-12-13 01:37:51',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(56,NULL,'PED-20251213-5453','Claudia',NULL,'3025887988','',NULL,28000.00,'listo',1,'',10,5,NULL,NULL,NULL,'2025-12-13 01:40:01','2025-12-13 01:57:59',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(57,1,'PED-20251213-0AB210','claudia',NULL,'3025887988','carrera 2#26E-28','',34500.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-13 01:48:32','2025-12-13 01:58:37',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.09895570,-76.21446110,1.00,4500.00),(58,NULL,'TEST-1765608700','PRUEBA DE SONIDO',NULL,'','',NULL,1000.00,'pendiente',1,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-13 01:51:40','2025-12-13 01:59:11',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(59,NULL,'PED-20251213-5254','Claudia',NULL,'3025887988','',NULL,2000.00,'listo',1,'',1,5,NULL,NULL,NULL,'2025-12-13 01:55:12','2025-12-13 02:00:38',NULL,0,0,NULL,0,'mesa','web',NULL,0,NULL,NULL,NULL,NULL),(60,1,'PED-20251213-288E6B','claudia',NULL,'3025887988','carrera 2#26E-28','',6500.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-13 02:02:10','2025-12-13 02:19:17',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.09895570,-76.21446110,1.00,4500.00),(61,1,'PED-20251213-3978D1','claudia',NULL,'3025887988','carrera 2#26E-28','',2000.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-13 02:07:47','2025-12-13 02:19:09',NULL,0,0,NULL,0,'domicilio','web',NULL,0,NULL,NULL,NULL,NULL),(62,1,'PED-20251213-143A49','Claudia alzate',NULL,'3025887988','Calle 26 11-50','',6310.00,'entregado',1,'',NULL,NULL,4,NULL,NULL,'2025-12-13 02:17:21','2025-12-13 02:18:59',NULL,0,0,NULL,0,'domicilio','web',NULL,0,4.08973650,-76.21813130,0.62,4310.00);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_items`
--

DROP TABLE IF EXISTS `pedidos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `plato_id` int(11) DEFAULT NULL,
  `plato_nombre` varchar(100) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pedido_id` (`pedido_id`),
  KEY `idx_plato_id` (`plato_id`),
  CONSTRAINT `pedidos_items_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pedidos_items_ibfk_2` FOREIGN KEY (`plato_id`) REFERENCES `platos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_items`
--

LOCK TABLES `pedidos_items` WRITE;
/*!40000 ALTER TABLE `pedidos_items` DISABLE KEYS */;
INSERT INTO `pedidos_items` VALUES (1,1,6,'Pasta Alfredo',26000.00,1,26000.00),(2,1,12,'Limonada Natural',5000.00,1,5000.00),(3,2,9,'Tiramisú',12000.00,1,12000.00),(4,3,14,'Café Americano',2000.00,1,0.00),(5,3,13,'Jugo de Naranja',5000.00,1,0.00),(6,3,7,'Lasaña',20000.00,1,0.00),(7,4,4,'Filete de Res',45000.00,1,0.00),(8,4,7,'Lasaña',20000.00,1,0.00),(9,5,3,'Bruschetta',28000.00,1,28000.00),(10,6,14,'Café Americano',2000.00,1,2000.00),(11,7,14,'Café Americano',2000.00,1,0.00),(12,8,13,'Jugo de Naranja',5000.00,1,5000.00),(13,9,14,'Café Americano',2000.00,1,2000.00),(14,10,12,'Limonada Natural',5000.00,1,0.00),(15,11,12,'Limonada Natural',5000.00,1,0.00),(16,12,14,'Café Americano',2000.00,1,2000.00),(17,13,14,'Café Americano',2000.00,1,2000.00),(18,13,13,'Jugo de Naranja',5000.00,1,5000.00),(19,14,7,'Lasaña',20000.00,1,0.00),(20,15,12,'Limonada Natural',5000.00,1,0.00),(21,16,14,'Café Americano',2000.00,1,2000.00),(22,17,13,'Jugo de Naranja',5000.00,1,0.00),(23,17,12,'Limonada Natural',5000.00,1,0.00),(24,18,12,'Limonada Natural',5000.00,1,0.00),(25,19,13,'Jugo de Naranja',5000.00,1,0.00),(26,19,12,'Limonada Natural',5000.00,1,0.00),(27,20,12,'Limonada Natural',5000.00,1,0.00),(28,21,8,'Pizza Margherita',31000.00,1,0.00),(29,22,4,'Filete de Res',45000.00,1,0.00),(30,23,7,'Lasaña',20000.00,1,0.00),(31,24,13,'Jugo de Naranja',5000.00,2,10000.00),(32,28,14,'Café Americano',2000.00,1,2000.00),(33,28,3,'Bruschetta',28000.00,1,28000.00),(34,31,4,'Filete de Res',45000.00,1,0.00),(35,34,NULL,'Café Americano',8000.00,1,8000.00),(36,37,NULL,'Pizza Margherita',15000.00,1,15000.00),(37,37,NULL,'Limonada Natural',5000.00,2,10000.00),(38,40,9,'Tiramisú',12000.00,1,12000.00),(39,41,9,'Tiramisú',12000.00,1,12000.00),(40,42,9,'Tiramisú',12000.00,1,12000.00),(41,43,1,'Plato Prueba',15000.00,1,15000.00),(42,44,9,'Tiramisú',12000.00,1,12000.00),(43,46,9,'Tiramisú',12000.00,1,12000.00),(44,47,9,'Tiramisú',12000.00,1,12000.00),(45,48,9,'Tiramisú',12000.00,1,12000.00),(46,49,5,'Pollo al Horno',19000.00,1,19000.00),(47,50,9,'Tiramisú',12000.00,1,12000.00),(48,50,11,'Helado Artesanal',13000.00,1,13000.00),(49,51,14,'Café Americano',2000.00,1,2000.00),(50,51,4,'Filete de Res',45000.00,1,45000.00),(51,52,14,'Café Americano',2000.00,1,2000.00),(52,53,14,'Café Americano',2000.00,1,2000.00),(53,54,14,'Café Americano',2000.00,1,2000.00),(54,55,13,'Jugo de Naranja',5000.00,1,0.00),(55,56,3,'Bruschetta',28000.00,1,0.00),(56,57,3,'Bruschetta',28000.00,1,28000.00),(57,57,14,'Café Americano',2000.00,1,2000.00),(58,59,14,'Café Americano',2000.00,1,0.00),(59,60,14,'Café Americano',2000.00,1,2000.00),(60,61,14,'Café Americano',2000.00,1,2000.00),(61,62,14,'Café Americano',2000.00,1,2000.00);
/*!40000 ALTER TABLE `pedidos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_log`
--

DROP TABLE IF EXISTS `pedidos_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `estado_anterior` varchar(50) DEFAULT NULL,
  `estado_nuevo` varchar(50) DEFAULT NULL,
  `script` varchar(100) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pedido` (`pedido_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_log`
--

LOCK TABLES `pedidos_log` WRITE;
/*!40000 ALTER TABLE `pedidos_log` DISABLE KEYS */;
INSERT INTO `pedidos_log` VALUES (1,32,'preparando','listo','marcar_listo.php','2025-12-08 07:16:24'),(2,33,'preparando','listo','marcar_listo.php','2025-12-08 07:16:27'),(3,34,'preparando','listo','marcar_listo.php','2025-12-08 07:16:28'),(4,35,'preparando','listo','marcar_listo.php','2025-12-08 07:16:29'),(5,36,'preparando','listo','marcar_listo.php','2025-12-08 07:16:30'),(6,36,'preparando','listo','marcar_listo.php','2025-12-08 07:22:10'),(7,37,'preparando','listo','marcar_listo.php','2025-12-08 07:22:12'),(8,37,'preparando','listo','marcar_listo.php','2025-12-08 07:40:37'),(9,36,'preparando','listo','marcar_listo.php','2025-12-08 07:46:49'),(10,33,'preparando','listo','marcar_listo.php','2025-12-08 07:46:51'),(11,34,'preparando','listo','marcar_listo.php','2025-12-08 07:46:52'),(12,35,'preparando','listo','marcar_listo.php','2025-12-08 07:46:53'),(13,32,'preparando','listo','marcar_listo.php','2025-12-08 07:46:54'),(14,40,'preparando','listo','marcar_listo.php','2025-12-08 08:33:02'),(15,40,'preparando','listo','marcar_listo.php','2025-12-08 08:42:35'),(16,41,'preparando','listo','marcar_listo.php','2025-12-08 08:45:12'),(17,40,'preparando','listo','marcar_listo.php','2025-12-08 08:48:25'),(18,41,'preparando','listo','marcar_listo.php','2025-12-08 08:48:27'),(19,42,'preparando','listo','marcar_listo.php','2025-12-08 08:54:38'),(20,44,'preparando','listo','marcar_listo.php','2025-12-08 09:05:20'),(21,44,'preparando','listo','marcar_listo.php','2025-12-08 09:09:42');
/*!40000 ALTER TABLE `pedidos_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platos`
--

DROP TABLE IF EXISTS `platos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen_ruta` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT 'General',
  `popular` tinyint(1) DEFAULT 0,
  `nuevo` tinyint(1) DEFAULT 0,
  `vegano` tinyint(1) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_popular` (`popular`),
  KEY `idx_nuevo` (`nuevo`),
  KEY `idx_vegano` (`vegano`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platos`
--

LOCK TABLES `platos` WRITE;
/*!40000 ALTER TABLE `platos` DISABLE KEYS */;
INSERT INTO `platos` VALUES (1,'Ensalada César','Lechuga romana, crutones, queso parmesano y aderezo César',28000.00,'imagenes_platos/1764824222_6931149e1d357.jpg','Entradas',1,0,0,'2025-12-04 04:36:58'),(2,'Sopa de Tomate','Sopa cremosa de tomate con albahaca fresca',15000.00,'imagenes_platos/1764824320_69311500d9acf.jpg','Entradas',0,0,1,'2025-12-04 04:36:58'),(3,'Bruschetta','Pan tostado con tomate, albahaca y aceite de oliva',28000.00,'imagenes_platos/1764824154_6931145aa43d5.jpg','Entradas',1,0,1,'2025-12-04 04:36:58'),(4,'Filete de Res','Filete de res a la parrilla con papas y vegetales',45000.00,'imagenes_platos/1764824349_6931151d2509e.jpg','Platos Principales',1,0,0,'2025-12-04 04:36:58'),(5,'Pollo al Horno','Pollo asado con hierbas y especias',19000.00,'imagenes_platos/1764868363_cd3e0e376398ae04.jpg','Platos Principales',1,0,0,'2025-12-04 04:36:58'),(6,'Pasta Alfredo','Fettuccine en salsa cremosa de queso',26000.00,'imagenes_platos/1764824489_693115a92c4b0.jpg','Platos Principales',0,0,0,'2025-12-04 04:36:58'),(7,'Lasaña','Lasaña de carne con salsa bechamel',20000.00,'imagenes_platos/1764824456_69311588be6e5.png','Platos Principales',1,0,0,'2025-12-04 04:36:58'),(8,'Pizza Margherita','Pizza con tomate, mozzarella y albahaca',31000.00,'imagenes_platos/1764868269_cd47ba15e3b876fb.jpg','Platos Principales',0,1,1,'2025-12-04 04:36:58'),(9,'Tiramisú','Postre italiano con café y mascarpone',12000.00,'imagenes_platos/1764827121_8777ccd444d49b74.jpg','Postres',1,0,0,'2025-12-04 04:36:58'),(10,'Cheesecake','Tarta de queso con frutos rojos',10000.00,'imagenes_platos/1764868416_5301351476d01697.jpg','Postres',1,0,0,'2025-12-04 04:36:58'),(11,'Helado Artesanal','Tres bolas de helado artesanal',13000.00,'imagenes_platos/1764868524_3830481489a5e48a.jpg','Postres',0,0,0,'2025-12-04 04:36:58'),(12,'Limonada Natural','Limonada fresca recién exprimida',5000.00,'imagenes_platos/1764824026_693113da40c29.jpg','Bebidas',0,0,1,'2025-12-04 04:36:58'),(13,'Jugo de Naranja','Jugo de naranja natural',5000.00,'imagenes_platos/1764823946_6931138a3ff81.jpg','Bebidas',0,0,1,'2025-12-04 04:36:58'),(14,'Café Americano','Café negro recién hecho',2000.00,'imagenes_platos/1764823815_69311307b9d2d.jpg','Bebidas',0,0,1,'2025-12-04 04:36:58'),(15,'Té Helado','Té negro con limón y hielo',5000.00,'imagenes_platos/1764824093_6931141d73471.jpg','Bebidas',0,1,1,'2025-12-04 04:36:58');
/*!40000 ALTER TABLE `platos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_ingredientes`
--

DROP TABLE IF EXISTS `proveedor_ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor_ingredientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_proveedor_ingrediente` (`proveedor_id`,`ingrediente_id`),
  KEY `idx_proveedor` (`proveedor_id`),
  KEY `idx_ingrediente` (`ingrediente_id`),
  CONSTRAINT `proveedor_ingredientes_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `proveedor_ingredientes_ibfk_2` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_ingredientes`
--

LOCK TABLES `proveedor_ingredientes` WRITE;
/*!40000 ALTER TABLE `proveedor_ingredientes` DISABLE KEYS */;
INSERT INTO `proveedor_ingredientes` VALUES (1,1,1,2500.00),(2,1,2,2000.00),(3,1,3,8000.00),(4,2,4,12000.00),(5,2,5,18000.00),(6,3,6,3000.00),(7,3,7,4000.00);
/*!40000 ALTER TABLE `proveedor_ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Distribuidora La Cosecha','Juan Pérez','3001234567','ventas@lacosecha.com','Calle 45 #23-15',NULL,1,'2025-12-07 11:06:32'),(2,'Carnes Premium','María González','3109876543','info@carnespremium.com','Av. 68 #12-34',NULL,1,'2025-12-07 11:06:32'),(3,'Granos del Valle','Carlos Rodríguez','3201122334','contacto@granosdelvalle.com','Carrera 30 #45-67',NULL,1,'2025-12-07 11:06:32');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publicidad`
--

DROP TABLE IF EXISTS `publicidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publicidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `tipo` enum('imagen','video','flyer') NOT NULL,
  `archivo_url` varchar(255) NOT NULL,
  `link_destino` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `orden` int(11) DEFAULT 0,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activo` (`activo`),
  KEY `idx_orden` (`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publicidad`
--

LOCK TABLES `publicidad` WRITE;
/*!40000 ALTER TABLE `publicidad` DISABLE KEYS */;
INSERT INTO `publicidad` VALUES (1,'Semana de la hamburguesa','imagen','693cfc4ba8e52.jpg','',NULL,1,0,'2025-12-13','2025-12-14','2025-12-13 05:40:27'),(2,'Semana de la hamburguesa','imagen','693cfc6b4a07f.jpg','',NULL,1,0,'2025-12-13','2025-12-14','2025-12-13 05:40:59');
/*!40000 ALTER TABLE `publicidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rangos_tarifas_domicilio`
--

DROP TABLE IF EXISTS `rangos_tarifas_domicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rangos_tarifas_domicilio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `distancia_min` decimal(10,2) NOT NULL COMMENT 'Distancia mínima en km',
  `distancia_max` decimal(10,2) NOT NULL COMMENT 'Distancia máxima en km',
  `tarifa` decimal(10,2) NOT NULL COMMENT 'Tarifa para este rango en COP',
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_distancia` (`distancia_min`,`distancia_max`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rangos_tarifas_domicilio`
--

LOCK TABLES `rangos_tarifas_domicilio` WRITE;
/*!40000 ALTER TABLE `rangos_tarifas_domicilio` DISABLE KEYS */;
INSERT INTO `rangos_tarifas_domicilio` VALUES (1,0.00,3.00,5000.00,1),(2,3.01,5.00,7000.00,1),(3,5.01,10.00,10000.00,1);
/*!40000 ALTER TABLE `rangos_tarifas_domicilio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recetas`
--

DROP TABLE IF EXISTS `recetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plato_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  `cantidad_necesaria` decimal(10,2) NOT NULL,
  `unidad_medida` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_plato_ingrediente` (`plato_id`,`ingrediente_id`),
  KEY `idx_plato` (`plato_id`),
  KEY `idx_ingrediente` (`ingrediente_id`),
  CONSTRAINT `recetas_ibfk_1` FOREIGN KEY (`plato_id`) REFERENCES `platos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recetas_ibfk_2` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recetas`
--

LOCK TABLES `recetas` WRITE;
/*!40000 ALTER TABLE `recetas` DISABLE KEYS */;
/*!40000 ALTER TABLE `recetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_chatbot_config`
--

DROP TABLE IF EXISTS `saas_chatbot_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_chatbot_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `chatbot_name` varchar(100) DEFAULT 'AsistenteBot',
  `welcome_message` text DEFAULT NULL,
  `primary_color` varchar(7) DEFAULT '#f97316',
  `enable_reservations` tinyint(1) DEFAULT 1,
  `enable_delivery` tinyint(1) DEFAULT 1,
  `enable_whatsapp` tinyint(1) DEFAULT 0,
  `whatsapp_number` varchar(50) DEFAULT NULL,
  `ai_provider` enum('anthropic','openai') DEFAULT 'anthropic',
  `api_key` varchar(255) DEFAULT NULL,
  `system_prompt` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `business_hours` varchar(255) DEFAULT NULL,
  `restaurant_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `saas_chatbot_config_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `saas_tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_chatbot_config`
--

LOCK TABLES `saas_chatbot_config` WRITE;
/*!40000 ALTER TABLE `saas_chatbot_config` DISABLE KEYS */;
INSERT INTO `saas_chatbot_config` VALUES (1,1,'ChatBot','¡Hola! 👋 Soy ChatBot, tu asistente virtual. ¿En qué puedo ayudarte?','#f97316',1,1,1,'+573177731338','openai','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',NULL,'2025-12-06 05:13:25','2025-12-06 06:05:29',NULL,NULL,NULL,NULL),(2,2,'Mi Restaurante Bot','¡Hola! 👋 Bienvenido a Mi Restaurante. ¿En qué puedo ayudarte hoy?','#667eea',1,1,1,'+573177731338','anthropic','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',NULL,'2025-12-06 06:19:11','2025-12-06 07:43:02','3177731338','carrera 2 # 26E-28','Lunes a Domingo: 12:00 PM - 10:00 PM','Dburger');
/*!40000 ALTER TABLE `saas_chatbot_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_conversations`
--

DROP TABLE IF EXISTS `saas_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  `customer_phone` varchar(50) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `status` enum('active','completed','abandoned') DEFAULT 'active',
  `order_placed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `saas_conversations_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `saas_tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_conversations`
--

LOCK TABLES `saas_conversations` WRITE;
/*!40000 ALTER TABLE `saas_conversations` DISABLE KEYS */;
INSERT INTO `saas_conversations` VALUES (1,1,'session_1764998695941_th6buwjfi',NULL,NULL,'active',0,'2025-12-06 05:25:04','2025-12-06 05:25:04'),(2,1,'session_1764998736016_glr0neuiv',NULL,NULL,'active',0,'2025-12-06 05:26:07','2025-12-06 05:26:07'),(3,1,'session_1764998843961_7vmqcf158',NULL,NULL,'active',0,'2025-12-06 05:27:34','2025-12-06 05:27:34'),(4,1,'test_1764998957',NULL,NULL,'active',0,'2025-12-06 05:29:17','2025-12-06 05:29:17'),(5,1,'session_1764999507778_s7pnni51s',NULL,NULL,'active',0,'2025-12-06 05:38:38','2025-12-06 05:38:38'),(6,1,'test_1764999642',NULL,NULL,'active',0,'2025-12-06 05:40:42','2025-12-06 05:40:42'),(7,1,'test_1764999663',NULL,NULL,'active',0,'2025-12-06 05:41:03','2025-12-06 05:41:03'),(8,1,'test_1764999846',NULL,NULL,'active',0,'2025-12-06 05:44:06','2025-12-06 05:44:06'),(9,1,'session_1764999863163_vatmiljza',NULL,NULL,'active',0,'2025-12-06 05:44:31','2025-12-06 05:44:31'),(10,1,'session_1764999909793_3i54loxla',NULL,NULL,'active',0,'2025-12-06 05:45:16','2025-12-06 05:45:16'),(11,2,'session_1765002049125_k1ydgv78b',NULL,NULL,'active',0,'2025-12-06 06:21:13','2025-12-06 06:21:13'),(12,2,'session_1765002472958_v0tu0d6nt',NULL,NULL,'active',0,'2025-12-06 06:28:06','2025-12-06 06:28:06'),(13,2,'session_1765002952392_3j2wcho28',NULL,NULL,'active',0,'2025-12-06 06:36:16','2025-12-06 06:36:16'),(14,2,'test_session_123',NULL,NULL,'active',0,'2025-12-06 07:30:15','2025-12-06 07:30:15'),(15,2,'session_1765006231145_dd706qmrd',NULL,NULL,'active',0,'2025-12-06 07:31:05','2025-12-06 07:31:05'),(16,2,'session_1765006352460_lzsy55fks',NULL,NULL,'active',0,'2025-12-06 07:32:38','2025-12-06 07:32:38'),(17,2,'session_1765006610036_jhnc1kam3',NULL,NULL,'active',0,'2025-12-06 07:36:57','2025-12-06 07:36:57'),(18,2,'test_info_1765007007',NULL,NULL,'active',0,'2025-12-06 07:43:27','2025-12-06 07:43:27'),(19,2,'test_info2_1765007011',NULL,NULL,'active',0,'2025-12-06 07:43:31','2025-12-06 07:43:31'),(20,2,'test_info3_1765007015',NULL,NULL,'active',0,'2025-12-06 07:43:35','2025-12-06 07:43:35'),(21,1,'test_1765111180',NULL,NULL,'active',0,'2025-12-07 12:39:40','2025-12-07 12:39:40'),(22,2,'session_1765170302823_thn3m37vl',NULL,NULL,'active',0,'2025-12-08 05:08:49','2025-12-08 05:08:49'),(23,2,'session_1765174165587_kd84i9srq',NULL,NULL,'active',0,'2025-12-08 06:09:42','2025-12-08 06:09:42'),(24,2,'session_1765172950534_iqogkllyf',NULL,NULL,'completed',1,'2025-12-08 06:21:33','2025-12-08 06:23:27'),(25,2,'session_1765248327109_y6sls0659',NULL,NULL,'active',0,'2025-12-09 02:45:46','2025-12-09 02:45:46');
/*!40000 ALTER TABLE `saas_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_menu_items`
--

DROP TABLE IF EXISTS `saas_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_menu_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `available` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_category` (`category`),
  KEY `idx_available` (`available`),
  CONSTRAINT `saas_menu_items_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `saas_tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_menu_items`
--

LOCK TABLES `saas_menu_items` WRITE;
/*!40000 ALTER TABLE `saas_menu_items` DISABLE KEYS */;
INSERT INTO `saas_menu_items` VALUES (1,1,'Pizza Margarita','Platos',25000.00,'Deliciosa pizza con tomate y mozzarella',NULL,0,'2025-12-06 05:13:25','2025-12-06 06:01:09'),(2,1,'Hamburguesa Clásica','Platos',18000.00,'Carne, lechuga, tomate y queso',NULL,1,'2025-12-06 05:13:25','2025-12-06 05:13:25'),(3,1,'Coca-Cola','Bebidas',3000.00,'Refresco 500ml',NULL,1,'2025-12-06 05:13:25','2025-12-06 05:13:25'),(4,1,'Limonada Natural','Bebidas',5000.00,'Limonada fresca',NULL,1,'2025-12-06 05:13:25','2025-12-06 05:13:25'),(5,1,'Brownie','Postres',10000.00,'Brownie con helado',NULL,1,'2025-12-06 05:13:25','2025-12-06 05:13:25'),(21,2,'Café Americano','Bebidas',2000.00,'Café negro recién hecho','imagenes_platos/1764823815_69311307b9d2d.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(22,2,'Jugo de Naranja','Bebidas',5000.00,'Jugo de naranja natural','imagenes_platos/1764823946_6931138a3ff81.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(23,2,'Limonada Natural','Bebidas',5000.00,'Limonada fresca recién exprimida','imagenes_platos/1764824026_693113da40c29.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(24,2,'Té Helado','Bebidas',5000.00,'Té negro con limón y hielo','imagenes_platos/1764824093_6931141d73471.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(25,2,'Bruschetta','Entradas',28000.00,'Pan tostado con tomate, albahaca y aceite de oliva','imagenes_platos/1764824154_6931145aa43d5.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(26,2,'Ensalada César','Entradas',28000.00,'Lechuga romana, crutones, queso parmesano y aderezo César','imagenes_platos/1764824222_6931149e1d357.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(27,2,'Sopa de Tomate','Entradas',15000.00,'Sopa cremosa de tomate con albahaca fresca','imagenes_platos/1764824320_69311500d9acf.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(28,2,'Filete de Res','Platos Principales',45000.00,'Filete de res a la parrilla con papas y vegetales','imagenes_platos/1764824349_6931151d2509e.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(29,2,'Lasaña','Platos Principales',20000.00,'Lasaña de carne con salsa bechamel','imagenes_platos/1764824456_69311588be6e5.png',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(30,2,'Pasta Alfredo','Platos Principales',26000.00,'Fettuccine en salsa cremosa de queso','imagenes_platos/1764824489_693115a92c4b0.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(31,2,'Pizza Margherita','Platos Principales',31000.00,'Pizza con tomate, mozzarella y albahaca','imagenes_platos/1764868269_cd47ba15e3b876fb.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(32,2,'Pollo al Horno','Platos Principales',19000.00,'Pollo asado con hierbas y especias','imagenes_platos/1764868363_cd3e0e376398ae04.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(33,2,'Cheesecake','Postres',10000.00,'Tarta de queso con frutos rojos','imagenes_platos/1764868416_5301351476d01697.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(34,2,'Helado Artesanal','Postres',13000.00,'Tres bolas de helado artesanal','imagenes_platos/1764868524_3830481489a5e48a.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39'),(35,2,'Tiramisú','Postres',12000.00,'Postre italiano con café y mascarpone','imagenes_platos/1764827121_8777ccd444d49b74.jpg',1,'2025-12-06 06:23:39','2025-12-06 06:23:39');
/*!40000 ALTER TABLE `saas_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_messages`
--

DROP TABLE IF EXISTS `saas_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) NOT NULL,
  `role` enum('user','assistant') NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_conversation` (`conversation_id`),
  CONSTRAINT `saas_messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `saas_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_messages`
--

LOCK TABLES `saas_messages` WRITE;
/*!40000 ALTER TABLE `saas_messages` DISABLE KEYS */;
INSERT INTO `saas_messages` VALUES (1,1,'user','hola','2025-12-06 05:25:04'),(2,2,'user','hola','2025-12-06 05:26:07'),(3,2,'user','hola','2025-12-06 05:26:38'),(4,3,'user','hola','2025-12-06 05:27:34'),(5,4,'user','Hola','2025-12-06 05:29:17'),(6,5,'user','hola','2025-12-06 05:38:38'),(7,6,'user','Hola','2025-12-06 05:40:42'),(8,7,'user','Hola','2025-12-06 05:41:03'),(9,8,'user','Hola','2025-12-06 05:44:06'),(10,8,'assistant','¡Hola! ¿Cómo puedo ayudarte hoy? ¿Estás listo para ver nuestro menú?','2025-12-06 05:44:09'),(11,9,'user','hola','2025-12-06 05:44:31'),(12,9,'assistant','¡Hola! ¿Cómo puedo ayudarte hoy en Restaurante Demo? 😊','2025-12-06 05:44:33'),(13,10,'user','listo','2025-12-06 05:45:16'),(14,10,'assistant','¡Hola! ¿Listo para hacer tu pedido? Puedo ayudarte a elegir algo delicioso de nuestro menú. ¿Te gustaría empezar con una bebida o un plato?','2025-12-06 05:45:18'),(15,11,'user','tienen servicio','2025-12-06 06:21:13'),(16,11,'user','tienen servicio','2025-12-06 06:21:39'),(17,11,'user','menu','2025-12-06 06:21:45'),(18,12,'user','hola tiene servicio','2025-12-06 06:28:06'),(19,12,'assistant','¡Hola! Sí, tenemos servicio a domicilio. ¿Te gustaría ver el menú o hacer un pedido?','2025-12-06 06:28:07'),(20,12,'user','menu','2025-12-06 06:28:21'),(21,12,'assistant','Aquí tienes nuestro menú:\n\n**BEBIDAS:**\n- Café Americano: ${price} (Café negro recién hecho)\n- Jugo de Naranja: ${price} (Jugo de naranja natural)\n- Limonada Natural: ${price} (Limonada fresca recién exprimida)\n- Té Helado: ${price} (Té negro con limón y hielo)\n\n**ENTRADAS:**\n- Bruschetta: ${price} (Pan tostado con tomate, albahaca y aceite de oliva)\n- Ensalada César: ${price} (Lechuga romana, crutones, queso parmesano y aderezo César)\n- Sopa de Tomate: ${price} (Sopa cremosa de tomate con albahaca fresca)\n\n**PLATOS PRINCIPALES:**\n- Filete de Res: ${price} (Filete de res a la parrilla con papas y vegetales)\n- Lasaña: ${price} (Lasaña de carne con salsa bechamel)\n- Pasta Alfredo: ${price} (Fettuccine en salsa cremosa de queso)\n- Pizza Margherita: ${price} (Pizza con tomate, mozzarella y albahaca)\n- Pollo al Horno: ${price} (Pollo asado con hierbas y especias)\n\n**POSTRES:**\n- Cheesecake: ${price} (Tarta de queso con frutos rojos)\n- Helado Artesanal: ${price} (Tres bolas de helado artesanal)\n- Tiramisú: ${price} (Postre italiano con café y mascarpone)\n\nSi necesitas ayuda para elegir o hacer un pedido, ¡estaré encantado de ayudarte!','2025-12-06 06:28:28'),(22,12,'user','bien ordenados para entender y con su precio','2025-12-06 06:29:41'),(23,12,'assistant','¡Claro! Aquí tienes el menú bien organizado con los precios:\n\n**BEBIDAS:**\n- Café Americano: $2.00 (Café negro recién hecho)\n- Jugo de Naranja: $3.00 (Jugo de naranja natural)\n- Limonada Natural: $2.50 (Limonada fresca recién exprimida)\n- Té Helado: $2.00 (Té negro con limón y hielo)\n\n**ENTRADAS:**\n- Bruschetta: $4.00 (Pan tostado con tomate, albahaca y aceite de oliva)\n- Ensalada César: $5.00 (Lechuga romana, crutones, queso parmesano y aderezo César)\n- Sopa de Tomate: $3.50 (Sopa cremosa de tomate con albahaca fresca)\n\n**PLATOS PRINCIPALES:**\n- Filete de Res: $12.00 (Filete de res a la parrilla con papas y vegetales)\n- Lasaña: $10.00 (Lasaña de carne con salsa bechamel)\n- Pasta Alfredo: $9.00 (Fettuccine en salsa cremosa de queso)\n- Pizza Margherita: $8.00 (Pizza con tomate, mozzarella y albahaca)\n- Pollo al Horno: $11.00 (Pollo asado con hierbas y especias)\n\n**POSTRES:**\n- Cheesecake: $5.00 (Tarta de queso con frutos rojos)\n- Helado Artesanal: $4.00 (Tres bolas de helado artesanal)\n- Tiramisú: $5.50 (Postre italiano con café y mascarpone)\n\nSi quieres hacer un pedido o necesitas ayuda para elegir, ¡dímelo!','2025-12-06 06:29:49'),(24,12,'user','la direccion cual es','2025-12-06 06:30:19'),(25,12,'assistant','Lo siento, no tengo la dirección específica del restaurante. Pero si necesitas hacer un pedido, por favor indícame tu dirección de entrega y estaré encantado de ayudarte con el resto.','2025-12-06 06:30:20'),(26,12,'user','y el telefono','2025-12-06 06:30:49'),(27,12,'assistant','Lamentablemente, no tengo el número de teléfono del restaurante. Sin embargo, puedo ayudarte con tu pedido o reservaciones. ¿Te gustaría hacer un pedido o necesitas ayuda con algo más?','2025-12-06 06:30:51'),(28,12,'user','que plato me recomiendas','2025-12-06 06:31:22'),(29,12,'assistant','Te recomiendo probar el **Filete de Res**. Es un plato delicioso, a la parrilla, acompañado de papas y vegetales frescos. ¡Es uno de nuestros favoritos! ¿Te gustaría pedirlo o prefieres otra opción?','2025-12-06 06:31:24'),(30,13,'user','horarios de atencion','2025-12-06 06:36:16'),(31,13,'assistant','¡Hola! Nuestros horarios de atención son de lunes a domingo, de 12:00 PM a 10:00 PM. ¿Te gustaría hacer un pedido o reservar una mesa?','2025-12-06 06:36:20'),(32,13,'user','si','2025-12-06 06:36:45'),(33,13,'assistant','¡Excelente! ¿Qué te gustaría pedir del menú? Puedo ayudarte a elegir algo delicioso.','2025-12-06 06:36:47'),(34,13,'user','elija uno por mi tengo calor','2025-12-06 06:37:14'),(35,13,'assistant','¡Claro! Te recomiendo una Limonada Natural, refrescante y perfecta para el calor. ¿Te gustaría añadir alguna entrada o un plato principal a tu pedido?','2025-12-06 06:37:16'),(36,13,'user','solo la limonada','2025-12-06 06:37:34'),(37,13,'assistant','Perfecto, una Limonada Natural para ti. Solo necesito que me proporciones tu dirección de entrega y el método de pago.','2025-12-06 06:37:35'),(38,13,'user','carrera 2 # 28 28 efetivo','2025-12-06 06:38:18'),(39,13,'assistant','¡Gracias! Tu Limonada Natural será entregada en Carrera 2 # 28 28 y el pago será en efectivo. Tu pedido estará listo para ti muy pronto. ¡Disfruta! Si necesitas algo más, no dudes en decírmelo.','2025-12-06 06:38:20'),(40,14,'user','Hola','2025-12-06 07:30:15'),(41,14,'assistant','¡Hola! ¿Cómo puedo ayudarte hoy? ¿Te gustaría ver nuestro menú o hacer un pedido?','2025-12-06 07:30:17'),(42,15,'user','Hola','2025-12-06 07:31:05'),(43,15,'assistant','¡Hola! ¿Cómo puedo ayudarte hoy? ¿Te gustaría ver el menú o hacer un pedido?','2025-12-06 07:31:08'),(44,16,'user','hola','2025-12-06 07:32:38'),(45,16,'assistant','¡Hola! 👋 Bienvenido a Mi Restaurante. \n\nSoy tu asistente virtual y estoy aquí para ayudarte con tu pedido. Tenemos un delicioso menú con bebidas, entradas, platos principales y postres frescos. \n\n¿Te gustaría conocer nuestras especialidades o ya tienes algo en mente? 😊','2025-12-06 07:32:43'),(46,16,'user','esta cerrado','2025-12-06 07:33:02'),(47,16,'assistant','¡No, estamos abiertos y listos para atenderte! 😊\n\nNuestro servicio está disponible y puedes hacer tu pedido ahora mismo. Tenemos delivery disponible para llevarte la comida directamente a tu casa.\n\n¿Qué te provoca hoy? ¿Quizás algo de nuestros deliciosos platos principales como la Lasaña o el Filete de Res? 🍽️','2025-12-06 07:33:06'),(48,16,'user','muestrame el menu','2025-12-06 07:33:27'),(49,16,'assistant','¡Aquí tienes nuestro delicioso menú! 📋\n\n**BEBIDAS** 🥤\n- Café Americano - $5,000\n- Jugo de Naranja - $5,000  \n- Limonada Natural - $5,000\n- Té Helado - $5,000\n\n**ENTRADAS** 🥗\n- Bruschetta - $8,000\n- Ensalada César - $8,000\n- Sopa de Tomate - $8,000\n\n**PLATOS PRINCIPALES** 🍽️\n- Filete de Res - $25,000\n- Lasaña - $18,000\n- Pasta Alfredo - $16,000\n- Pizza Margherita - $15,000\n- Pollo al Horno - $20,000\n\n**POSTRES** 🍰\n- Cheesecake - $10,000\n- Helado Artesanal - $8,000\n- Tiramisú - $12,000\n\n¿Qué te llama la atención? ¡Te puedo recomendar un combo delicioso! 😋','2025-12-06 07:33:33'),(50,16,'user','un helado por favor','2025-12-06 07:34:05'),(51,16,'assistant','¡Perfecto! Un Helado Artesanal por $8,000 - son tres bolas de helado delicioso 🍦\n\n¿Te gustaría agregar algo más a tu pedido? Una bebida fresquita como nuestra Limonada Natural quedaría genial, o tal vez alguna entrada para compartir.\n\n¿O con el helado está bien para ti? 😊','2025-12-06 07:34:09'),(52,16,'user','solo el helado','2025-12-06 07:34:25'),(53,16,'assistant','¡Perfecto! Entonces tenemos:\n- 1 Helado Artesanal: $8,000\n\n**Total: $8,000**\n\nPara procesar tu pedido a domicilio, necesito algunos datos:\n- ¿Cuál es tu nombre?\n- ¿Tu número de teléfono?  \n- ¿La dirección de entrega?\n\n¡Te lo llevamos fresquito a casa! 🍦🏠','2025-12-06 07:34:30'),(54,16,'user','edwar jaramillo telefono 3025887986 direccion carrera 2 26E 28','2025-12-06 07:35:54'),(55,16,'user','edwar jaramillo','2025-12-06 07:36:19'),(56,17,'user','hola','2025-12-06 07:36:57'),(57,17,'assistant','¡Hola! 😊 Bienvenido a Mi Restaurante. \n\nSoy tu asistente virtual y estoy aquí para ayudarte. ¿Te gustaría conocer nuestro menú o ya tienes algo en mente para ordenar? También puedo ayudarte con reservaciones o información sobre nuestro servicio a domicilio.\n\n¿En qué puedo ayudarte hoy?','2025-12-06 07:37:01'),(58,18,'user','¿Cuál es la dirección del restaurante?','2025-12-06 07:43:27'),(59,18,'assistant','¡Hola! Bienvenido a Mi Restaurante 😊\n\nNuestra dirección es: **Carrera 2 # 26E-28**\n\nEstamos abiertos todos los días de 12:00 PM a 10:00 PM. También ofrecemos servicio a domicilio si prefieres disfrutar de nuestros deliciosos platos en casa.\n\n¿Te gustaría conocer nuestro menú o tienes alguna pregunta sobre nuestros platillos?','2025-12-06 07:43:31'),(60,19,'user','¿Cuál es el teléfono?','2025-12-06 07:43:31'),(61,19,'assistant','¡Hola! 😊 \n\nNuestro teléfono es **3177731338**. Puedes llamarnos para hacer reservaciones o consultas.\n\n¿Te gustaría conocer nuestro menú o necesitas ayuda con algo más?','2025-12-06 07:43:35'),(62,20,'user','¿Cuál es el horario de atención?','2025-12-06 07:43:35'),(63,20,'assistant','¡Hola! 😊 \n\nNuestro horario de atención es de **Lunes a Domingo de 12:00 PM a 10:00 PM**. ¡Estamos abiertos todos los días para atenderte!\n\n¿Te gustaría conocer nuestro menú o hacer algún pedido? Tenemos deliciosas opciones en bebidas, entradas, platos principales y postres.','2025-12-06 07:43:39'),(64,17,'user','telefono del whasap','2025-12-06 07:44:58'),(65,17,'assistant','El número de WhatsApp de Mi Restaurante es **3177731338** 📱\n\n¿Te gustaría que te ayude con algo más? Puedo mostrarte nuestro menú o ayudarte a hacer un pedido directamente por aquí. ¡Estamos abiertos de 12:00 PM a 10:00 PM todos los días! 😊','2025-12-06 07:45:02'),(66,17,'user','horarios','2025-12-06 07:45:17'),(67,17,'assistant','Nuestros horarios son:\n\n📅 **Lunes a Domingo: 12:00 PM - 10:00 PM**\n\nEstamos abiertos todos los días de la semana para servirte. ¿Te gustaría hacer una reservación o conocer nuestro menú para ordenar? 😊','2025-12-06 07:45:22'),(68,17,'user','esta cerrado','2025-12-06 07:45:44'),(69,17,'assistant','Tienes razón, en este momento estamos cerrados 😔\n\nNuestro horario es de **12:00 PM a 10:00 PM** todos los días. Pero no te preocupes, puedes contactarnos por WhatsApp al **3177731338** para hacer tu pedido con anticipación o reservar una mesa para mañana.\n\n¿Te gustaría que te muestre el menú para que vayas pensando en tu próxima visita? 🍽️','2025-12-06 07:45:49'),(70,17,'user','ok gracias luego pido','2025-12-06 07:46:23'),(71,17,'assistant','¡Perfecto! 😊 \n\nCuando gustes, estaremos aquí para atenderte. Recuerda que puedes escribirnos por WhatsApp al **3177731338** o volver por aquí cuando quieras hacer tu pedido.\n\n¡Que tengas un excelente día y esperamos verte pronto en Mi Restaurante! 🍽️✨','2025-12-06 07:46:28'),(72,21,'user','Hola','2025-12-07 12:39:40'),(73,22,'user','hola','2025-12-08 05:08:49'),(74,22,'assistant','¡Hola! 😊 Bienvenido a Mi Restaurante. \n\n¿Cómo puedo ayudarte hoy? ¿Te gustaría conocer nuestro menú, hacer un pedido o tal vez necesitas información sobre nuestros servicios de delivery?','2025-12-08 05:08:54'),(75,22,'user','dame el menu','2025-12-08 05:09:03'),(76,22,'assistant','¡Perfecto! Aquí tienes nuestro delicioso menú: 🍽️\n\n**BEBIDAS:**\n- Café Americano - $5,000\n- Jugo de Naranja - $8,000  \n- Limonada Natural - $7,000\n- Té Helado - $6,000\n\n**ENTRADAS:**\n- Bruschetta - $12,000\n- Ensalada César - $15,000\n- Sopa de Tomate - $10,000\n\n**PLATOS PRINCIPALES:**\n- Filete de Res - $35,000\n- Lasaña - $22,000\n- Pasta Alfredo - $18,000\n- Pizza Margherita - $20,000\n- Pollo al Horno - $25,000\n\n**POSTRES:**\n- Cheesecake - $12,000\n- Helado Artesanal - $8,000\n- Tiramisú - $14,000\n\n¿Algo te llama la atención? ¡Puedo recomendarte algunas combinaciones deliciosas! 😋','2025-12-08 05:09:09'),(77,22,'user','domo es el numero celular','2025-12-08 05:09:41'),(78,22,'assistant','Nuestro número de teléfono es: **3177731338** 📞\n\n¿Te gustaría hacer un pedido conmigo ahora o prefieres llamar directamente? ¡Estoy aquí para ayudarte con lo que necesites! 😊','2025-12-08 05:09:44'),(79,22,'user','voy hacer pedido','2025-12-08 05:10:09'),(80,22,'assistant','¡Excelente! 🎉 Estoy listo para tomar tu pedido.\n\n¿Qué te gustaría ordenar? Puedes decirme los platos que quieres y yo te voy anotando todo. ¿Empezamos con algo de beber o prefieres ir directo a los platos principales?','2025-12-08 05:10:13'),(81,22,'user','sopa de tomate','2025-12-08 05:10:33'),(82,22,'assistant','¡Perfecto! Anoto en tu pedido:\n\n✅ **2 Sopas de Tomate** - $20,000\n\n¿Te gustaría agregar algo más? Tal vez una entrada adicional, un plato principal o algo para beber que combine bien con las sopas? 🍲😊','2025-12-08 05:10:38'),(83,22,'user','no asi esta bien','2025-12-08 05:10:54'),(84,22,'assistant','¡Perfecto! Tu pedido está listo:\n\n**RESUMEN:**\n- 2 Sopas de Tomate: $20,000\n**Total: $20,000** 🍲\n\nPara completar el pedido necesito algunos datos:\n- ¿Tu nombre?\n- ¿Tu número de teléfono?\n- ¿La dirección donde quieres que te entreguemos el pedido?\n\n¡Y listo para disfrutar de nuestras deliciosas sopas! 😊','2025-12-08 05:10:59'),(85,22,'user','claudia alzate 3025887988 kra 2 # 26E 28','2025-12-08 05:11:52'),(86,22,'user','claudia alzate','2025-12-08 05:12:08'),(87,23,'user','Hola','2025-12-08 06:09:42'),(88,23,'assistant','¡Hola! Bienvenido a Mi Restaurante 😊\n\n¿Cómo estás? Te ayudo a conocer nuestro delicioso menú o a hacer tu pedido. Tenemos desde bebidas refrescantes y entradas, hasta platos principales y postres irresistibles.\n\n¿Qué te gustaría probar hoy o en qué te puedo ayudar?','2025-12-08 06:09:46'),(89,23,'user','Para hacer un pedido','2025-12-08 06:09:58'),(90,23,'assistant','¡Perfecto! Me encanta ayudarte con tu pedido 🍽️\n\nTenemos un menú muy variado:\n- **Bebidas**: Café, jugos naturales, limonada, té helado\n- **Entradas**: Bruschetta, ensalada César, sopa de tomate  \n- **Platos principales**: Filete de res, lasaña, pasta Alfredo, pizza Margherita, pollo al horno\n- **Postres**: Cheesecake, helado artesanal, tiramisú\n\n¿Qué se te antoja? ¿Prefieres que te recomiende algo o ya tienes algo en mente?','2025-12-08 06:10:03'),(91,23,'user','Una pasta alfredo','2025-12-08 06:10:33'),(92,23,'assistant','¡Excelente elección! 🍝 La Pasta Alfredo es una de nuestras especialidades - fettuccine en deliciosa salsa cremosa de queso por $15,000.\n\n¿Te gustaría agregar algo más? Una ensalada César combina perfecto, o quizás una bebida refrescante como limonada natural. También tenemos postres deliciosos como el tiramisú.\n\n¿Será solo la pasta Alfredo o quieres agregar algo más a tu pedido?','2025-12-08 06:10:38'),(93,23,'user','No','2025-12-08 06:10:48'),(94,23,'assistant','¡Perfecto! Entonces tu pedido es:\n- 1 Pasta Alfredo: $15,000\n\n**Total: $15,000**\n\nPara confirmar tu pedido y coordinar el domicilio, necesito algunos datos:\n- ¿Cuál es tu nombre?\n- ¿Tu número de teléfono?\n- ¿La dirección de entrega?\n\n¡Y te llega fresquita a tu casa! 🚗','2025-12-08 06:11:04'),(95,23,'user','Claudia alzate 3025887988 carrera 2#26E-28','2025-12-08 06:11:48'),(96,23,'user','Mi nombre es Claudia alzate','2025-12-08 06:12:11'),(97,24,'user','para hacer un pedido','2025-12-08 06:21:33'),(98,24,'assistant','¡Hola! Bienvenido a Mi Restaurante 😊\n\n¡Perfecto! Te ayudo con tu pedido. Tenemos un delicioso menú con bebidas, entradas, platos principales y postres.\n\n¿Qué te gustaría ordenar hoy? Puedo sugerirte nuestro popular Filete de Res con Pasta Alfredo, o si prefieres algo más ligero, la Ensalada César está excelente.','2025-12-08 06:21:37'),(99,24,'user','menu','2025-12-08 06:21:45'),(100,24,'assistant','Aquí está nuestro menú completo:\n\n**🥤 BEBIDAS:**\n- Café Americano: $8,000\n- Jugo de Naranja: $6,000  \n- Limonada Natural: $5,000\n- Té Helado: $4,000\n\n**🥗 ENTRADAS:**\n- Bruschetta: $12,000\n- Ensalada César: $15,000\n- Sopa de Tomate: $10,000\n\n**🍽️ PLATOS PRINCIPALES:**\n- Filete de Res: $35,000\n- Lasaña: $25,000\n- Pasta Alfredo: $22,000\n- Pizza Margherita: $20,000\n- Pollo al Horno: $28,000\n\n**🍰 POSTRES:**\n- Cheesecake: $12,000\n- Helado Artesanal: $8,000\n- Tiramisú: $14,000\n\n¿Qué te llama la atención? Puedo recomendarte un combo perfecto según tus gustos 😋','2025-12-08 06:21:53'),(101,24,'user','Café Americano: $8,000','2025-12-08 06:22:06'),(102,24,'assistant','¡Excelente elección! Un Café Americano por $8,000 🔥\n\n¿Te gustaría acompañarlo con algo más? Nuestro Cheesecake o Tiramisú van perfectos con café. O si prefieres algo salado, la Bruschetta es ideal para acompañar.\n\n¿Algo más para tu pedido o confirmas solo el Café Americano?','2025-12-08 06:22:10'),(103,24,'user','solo eso','2025-12-08 06:22:22'),(104,24,'assistant','Perfecto! Tu pedido es:\n- 1 Café Americano: $8,000\n\n**Total: $8,000**\n\nPara confirmar tu pedido y coordinar la entrega a domicilio, necesito:\n📍 Tu dirección de entrega\n📱 Tu número de teléfono  \n👤 Tu nombre\n\n¿Me puedes dar estos datos por favor?','2025-12-08 06:22:26'),(105,24,'user','carrera 22 #26E 28  3025887988  claudia alzate','2025-12-08 06:23:22'),(106,24,'assistant','¡Perfecto Claudia! He confirmado tu pedido:\n\n📋 **RESUMEN:**\n- Cliente: Claudia Alzate\n- Teléfono: 3025887988\n- Dirección: Carrera 22 #26E-28\n- Pedido: 1 Café Americano\n- Total: $8,000\n\nTu café llegará en aproximadamente 30-40 minutos. ¡Muchas gracias por elegir Mi Restaurante! ☕😊\n\n\n\n✅ *¡Pedido #34 confirmado!* Tu orden ha sido enviada a la cocina.','2025-12-08 06:23:27'),(107,25,'user','hola tienen servicio','2025-12-09 02:45:46'),(108,25,'assistant','¡Hola! 😊 \n\n¡Claro que sí! En Mi Restaurante ofrecemos servicio a domicilio y también puedes visitarnos en nuestro local en carrera 2 # 26E-28.\n\nNuestro horario es de lunes a domingo de 12:00 PM a 10:00 PM. ¿Te gustaría conocer nuestro menú o hacer un pedido a domicilio?','2025-12-09 02:45:50');
/*!40000 ALTER TABLE `saas_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_payments`
--

DROP TABLE IF EXISTS `saas_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('efectivo','transferencia','tarjeta','otro') DEFAULT 'transferencia',
  `status` enum('pendiente','completado','fallido','reembolsado') DEFAULT 'completado',
  `reference_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_status` (`status`),
  CONSTRAINT `saas_payments_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `saas_tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_payments`
--

LOCK TABLES `saas_payments` WRITE;
/*!40000 ALTER TABLE `saas_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `saas_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_super_admins`
--

DROP TABLE IF EXISTS `saas_super_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_super_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_super_admins`
--

LOCK TABLES `saas_super_admins` WRITE;
/*!40000 ALTER TABLE `saas_super_admins` DISABLE KEYS */;
INSERT INTO `saas_super_admins` VALUES (1,'admin@saas.com','$2y$10$TLeWqppDIIOcL7t.Ftbyle5UNLcPX2RL8CGzb8IOZWF.xozRFvnpK','Super Administrador','2025-12-07 13:20:52','2025-12-07 13:20:52');
/*!40000 ALTER TABLE `saas_super_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_tenants`
--

DROP TABLE IF EXISTS `saas_tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saas_tenants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(255) NOT NULL,
  `owner_email` varchar(255) NOT NULL,
  `owner_password` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `business_hours` varchar(100) DEFAULT NULL,
  `plan` enum('basic','pro','enterprise') DEFAULT 'basic',
  `subscription_start` date DEFAULT NULL,
  `subscription_end` date DEFAULT NULL,
  `next_billing_date` date DEFAULT NULL,
  `monthly_fee` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','suspended','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `owner_email` (`owner_email`),
  KEY `idx_email` (`owner_email`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_tenants`
--

LOCK TABLES `saas_tenants` WRITE;
/*!40000 ALTER TABLE `saas_tenants` DISABLE KEYS */;
INSERT INTO `saas_tenants` VALUES (1,'Restaurante Demo','demo@restaurante.com','$2y$10$3YHTSbX9LK/yvE8iKLVjD.e.BxzdWMsxNB5WZx.IN42o10GsWaO6W','+57 300 123 4567','Calle 123 #45-67, Bogotá','9:00 AM - 10:00 PM','pro','2025-12-07','2026-01-06','2026-01-06',50000.00,'active','2025-12-06 05:13:25','2025-12-07 13:20:52'),(2,'Mi Restaurante','admin@mirestaurante.com','$2y$10$qKuZCvvkeCx36ZtFDL/wWuJRTXU.3lMjrgdm0vtIQE3L6V/2C2TL6',NULL,NULL,NULL,'basic',NULL,NULL,NULL,0.00,'active','2025-12-06 06:19:11','2025-12-06 06:19:11');
/*!40000 ALTER TABLE `saas_tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ubicacion_domiciliarios`
--

DROP TABLE IF EXISTS `ubicacion_domiciliarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ubicacion_domiciliarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `latitud` decimal(10,8) NOT NULL,
  `longitud` decimal(11,8) NOT NULL,
  `ultima_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario_id` (`usuario_id`),
  CONSTRAINT `ubicacion_domiciliarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ubicacion_domiciliarios`
--

LOCK TABLES `ubicacion_domiciliarios` WRITE;
/*!40000 ALTER TABLE `ubicacion_domiciliarios` DISABLE KEYS */;
INSERT INTO `ubicacion_domiciliarios` VALUES (1,4,4.08192990,-76.21313610,'2025-12-09 04:40:37');
/*!40000 ALTER TABLE `ubicacion_domiciliarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `rol` enum('admin','mesero','chef','domiciliario','cajero') NOT NULL DEFAULT 'mesero',
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `ultimo_acceso` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `idx_usuario` (`usuario`),
  KEY `idx_rol` (`rol`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$/EoHCmPrTb7BUwItAGX.9O.V8OKSQtibIlhlOOWPGlJkEpUjAt4hO','Administrador Principal','edwarjm@gmail.com',NULL,'admin',1,'2025-12-03 23:36:58','2025-12-15 21:10:49'),(2,'mesero_test','$2y$10$EO7x..j5R2Urb4YWuKAw9epos3jLG3DPhU4PYIrywGeIfMVkMzie.','Juan Pérez (Mesero)','mesero@restaurante.com',NULL,'mesero',0,'2025-12-04 10:41:06','2025-12-04 12:57:46'),(3,'chef_test','$2y$10$tCkcw2HsN04z44hf35LPVumsqZt/1xjrr1HuPuFgv/pY3aThpx.12','María García (Chef)','chef@restaurante.com','','chef',1,'2025-12-04 10:41:06','2025-12-04 12:48:10'),(4,'domiciliario','$2y$10$gKfEwkAzF9tK.RHokQrICeNYVK72.JCKDSE2ApHKxq5oglPQHV2fu','edwar (Domiciliario)','edwarjm@hotmail.com','3001234567','domiciliario',1,'2025-12-04 10:41:06','2025-12-13 01:53:29'),(5,'Karen mesera','$2y$10$6LgVTJ2mtD6ATshGdZmMnuItYBEZozA9pzlDj4WTvWgkcWP8B9RX.','Karen Jaramillo','karendahianajaramilloalzate@gmail.com',NULL,'mesero',1,'2025-12-04 16:19:05','2025-12-13 01:39:06'),(6,'Emmanuel cosinero','$2y$10$6nu.DzpdmLe2dZry6UI5w.jeVrq9VmhRfh6V.obONoUMX65IrQCiu','emmanuel','emmanuel.jaramillo.alzate@gmail.com',NULL,'chef',1,'2025-12-04 17:40:43','2025-12-13 02:17:17'),(7,'cajero','$2y$10$yr3EftWfOYlm4mA3bry2ZeMU.dPowO3YkT9NXqR08rS.W7YAjCkQe','Cajero Principal','',NULL,'cajero',1,'2025-12-05 07:23:38','2025-12-13 02:18:48'),(11,'cajero1','$2y$10$2jcmsk2xq3OoyNLn.bBRtewhaGdVts4cKE66B/vWEKd29dXoV0bny','claudia alzate','claudialzate1234@hotmail.com',NULL,'cajero',1,'2025-12-08 00:36:17','2025-12-08 00:36:35'),(12,'edwar_domicilio','$2y$10$.ox68DwOtcHo6NpMVE36Y..2mQdb14vFSV.hiawbhnJLlg09BWsSW','edwar jaramillo','edwarjm@gmail.com',NULL,'domiciliario',1,'2025-12-08 03:12:26','2025-12-08 23:39:29');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 21:13:45
